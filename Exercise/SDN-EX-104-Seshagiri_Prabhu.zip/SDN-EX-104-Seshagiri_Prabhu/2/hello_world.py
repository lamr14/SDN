#! /usr/bin/env python2
"""
hello_world.py: A program to print "Hello World" to stdout
"""
__author__      = "Seshagiri Prabhu"
__copyright__   = "MIT License"

if __name__=="__main__":
    """
    Main function
    """
    print "Hello World"
